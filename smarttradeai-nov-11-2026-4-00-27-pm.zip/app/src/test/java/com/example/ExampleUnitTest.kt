package com.example

import com.example.data.model.Candle
import com.example.data.model.SignalType
import com.example.domain.engine.IndicatorCalculator
import com.example.domain.engine.SignalGenerator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testIndicatorCalculationAndSignals() {
        // Generate simulated uptrend candles
        val candles = mutableListOf<Candle>()
        var currentPrice = 90000.0
        val baseTime = 1700000000000L

        for (i in 0 until 50) {
            val open = currentPrice
            val close = open + (i * 20.0) // Steady uptrend
            val high = close + 15.0
            val low = open - 10.0
            val volume = 100.0 + i

            candles.add(
                Candle(
                    openTime = baseTime + (i * 60000),
                    open = open,
                    high = high,
                    low = low,
                    close = close,
                    volume = volume,
                    closeTime = baseTime + (i * 60000) + 59999
                )
            )
            currentPrice = close
        }

        val indicators = IndicatorCalculator.calculateIndicators(candles)

        // Verify EMA calculation
        assertNotNull(indicators.ema9)
        assertNotNull(indicators.ema21)
        assertTrue("EMA 9 should be greater than EMA 21 in uptrend", indicators.ema9!! > indicators.ema21!!)

        // Verify RSI
        assertNotNull(indicators.rsi14)
        assertTrue("RSI should be above 50 in uptrend", indicators.rsi14!! > 50.0)

        // Verify MACD
        assertNotNull(indicators.macdHistogram)
        assertTrue("MACD Histogram should be positive in strong uptrend", indicators.macdHistogram!! > 0.0)

        // Verify VWAP
        assertNotNull(indicators.vwap)
        assertTrue("Price should be above VWAP in uptrend", candles.last().close > indicators.vwap!!)

        // Verify ATR
        assertNotNull(indicators.atr14)
        assertTrue("ATR should be positive", indicators.atr14!! > 0.0)

        // Generate signal
        val signal = SignalGenerator.generateSignal(
            pair = "BTC/USDT",
            timeframe = "1m",
            currentPrice = candles.last().close,
            candles = candles,
            indicators = indicators
        )

        assertEquals(SignalType.BUY, signal.type)
        assertTrue("Stop loss should be below entry price for BUY", signal.stopLoss < signal.entryPrice)
        assertTrue("Target 1 should be above entry price for BUY", signal.target1 > signal.entryPrice)
        assertTrue("Target 2 should be above Target 1", signal.target2 > signal.target1)
        assertTrue("Reasons should not be empty", signal.reasons.isNotEmpty())
    }
}
