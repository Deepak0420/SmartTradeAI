package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MarketPair
import com.example.data.model.Ticker24h
import com.example.data.model.Timeframe
import com.example.ui.theme.BearishRed
import com.example.ui.theme.BearishRedBg
import com.example.ui.theme.BullishGreen
import com.example.ui.theme.BullishGreenBg
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun LivePriceCard(
    selectedPair: MarketPair,
    onSelectPair: (MarketPair) -> Unit,
    selectedTimeframe: Timeframe,
    onSelectTimeframe: (Timeframe) -> Unit,
    ticker: Ticker24h?,
    isLoading: Boolean,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(DarkSurface, RoundedCornerShape(12.dp))
            .border(1.dp, DarkBorder, RoundedCornerShape(12.dp))
            .padding(14.dp)
            .testTag("live_price_card")
    ) {
        // Pair & Timeframe Selector Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Pair Switcher (BTC / ETH)
            Row(
                modifier = Modifier
                    .background(DarkSurfaceVariant, RoundedCornerShape(8.dp))
                    .padding(2.dp)
            ) {
                MarketPair.values().forEach { pair ->
                    val isSelected = pair == selectedPair
                    Box(
                        modifier = Modifier
                            .background(
                                if (isSelected) CyanAccent else DarkSurfaceVariant,
                                RoundedCornerShape(6.dp)
                            )
                            .clickable { onSelectPair(pair) }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .testTag("pair_selector_${pair.symbol}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = pair.displayName,
                            color = if (isSelected) DarkSurface else TextSecondary,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Timeframe Switcher (1m / 5m / 15m)
            Row(
                modifier = Modifier
                    .background(DarkSurfaceVariant, RoundedCornerShape(8.dp))
                    .padding(2.dp)
            ) {
                Timeframe.values().forEach { tf ->
                    val isSelected = tf == selectedTimeframe
                    Box(
                        modifier = Modifier
                            .background(
                                if (isSelected) DarkBorder else DarkSurfaceVariant,
                                RoundedCornerShape(6.dp)
                            )
                            .clickable { onSelectTimeframe(tf) }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                            .testTag("tf_selector_${tf.interval}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = tf.interval,
                            color = if (isSelected) CyanAccent else TextMuted,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    color = CyanAccent,
                    strokeWidth = 2.dp
                )
            } else {
                IconButton(
                    onClick = onRefresh,
                    modifier = Modifier.size(32.dp).testTag("btn_refresh_price")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Refresh Market Price",
                        tint = CyanAccent,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Price Display Row
        val price = ticker?.lastPrice ?: 0.0
        val changePct = ticker?.priceChangePercent ?: 0.0
        val isPositive = changePct >= 0.0
        val changeColor = if (isPositive) BullishGreen else BearishRed
        val changeBg = if (isPositive) BullishGreenBg else BearishRedBg

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Bottom
        ) {
            Column {
                Text(
                    text = "Live Market Price (${selectedPair.quoteAsset})",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = if (price > 0.0) "$${formatNum(price)}" else "Connecting...",
                    color = TextPrimary,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.testTag("live_price_text")
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            Box(
                modifier = Modifier
                    .background(changeBg, RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "${if (isPositive) "+" else ""}${String.format(Locale.US, "%.2f", changePct)}% (24h)",
                    color = changeColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 24h High, Low, Volume
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkSurfaceVariant, RoundedCornerShape(6.dp))
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            MarketStat(label = "24h High", value = "$${formatNum(ticker?.highPrice ?: 0.0)}")
            MarketStat(label = "24h Low", value = "$${formatNum(ticker?.lowPrice ?: 0.0)}")
            MarketStat(label = "24h Volume", value = "${formatVolume(ticker?.volume ?: 0.0)} ${selectedPair.baseAsset}")
        }
    }
}

@Composable
private fun MarketStat(label: String, value: String) {
    Column {
        Text(text = label, color = TextMuted, fontSize = 10.sp)
        Text(text = value, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}

private fun formatNum(num: Double): String {
    return if (num >= 100) {
        String.format(Locale.US, "%,.2f", num)
    } else {
        String.format(Locale.US, "%,.4f", num)
    }
}

private fun formatVolume(vol: Double): String {
    return when {
        vol >= 1_000_000 -> String.format(Locale.US, "%.1fM", vol / 1_000_000)
        vol >= 1_000 -> String.format(Locale.US, "%.1fK", vol / 1_000)
        else -> String.format(Locale.US, "%.1f", vol)
    }
}
