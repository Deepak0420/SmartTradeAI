package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.auth.TraderProfile
import com.example.ui.components.RiskWarningBanner
import com.example.ui.theme.BearishRed
import com.example.ui.theme.BullishGreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RiskSettingsScreen(
    profile: TraderProfile,
    onUpdateProfile: (name: String, exp: String, risk: String, riskPct: Double) -> Unit,
    modifier: Modifier = Modifier
) {
    var traderName by remember(profile) { mutableStateOf(profile.traderName) }
    var selectedRisk by remember(profile) { mutableStateOf(profile.riskTolerance) }
    var riskPctText by remember(profile) { mutableStateOf(profile.riskPercentPerTrade.toString()) }

    // Position Size Calculator States
    var capitalInput by remember { mutableStateOf("1000") }
    var calcEntryInput by remember { mutableStateOf("91200") }
    var calcSlInput by remember { mutableStateOf("90400") }

    val capital = capitalInput.toDoubleOrNull() ?: 1000.0
    val entry = calcEntryInput.toDoubleOrNull() ?: 91200.0
    val sl = calcSlInput.toDoubleOrNull() ?: 90400.0
    val riskPercent = riskPctText.toDoubleOrNull() ?: 1.5

    val maxLossAllowed = capital * (riskPercent / 100.0)
    val distancePerUnit = abs(entry - sl)
    val safeUnits = if (distancePerUnit > 0.0) maxLossAllowed / distancePerUnit else 0.0
    val safePositionSizeUsd = safeUnits * entry

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = CyanAccent,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Risk Management & Profile",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkSurface,
                    titleContentColor = TextPrimary
                )
            )
        },
        containerColor = DarkBg,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(14.dp)
                .testTag("risk_settings_screen_content")
        ) {
            // Risk Warning
            RiskWarningBanner()

            Spacer(modifier = Modifier.height(14.dp))

            // 1. Position Size & Risk Calculator
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurface, RoundedCornerShape(12.dp))
                    .border(1.dp, CyanAccent.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                    .padding(14.dp)
                    .testTag("calculator_card")
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Calculate, contentDescription = null, tint = CyanAccent)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Smart Position Size Calculator",
                        color = CyanAccent,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Kitna trade size lena chahiye taaki SL hit hone par bhi tay shuda % se zyada loss na ho:",
                    color = TextSecondary,
                    fontSize = 11.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = capitalInput,
                        onValueChange = { capitalInput = it },
                        label = { Text("Capital ($)") },
                        modifier = Modifier.weight(1f).testTag("input_capital"),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = outlinedColors()
                    )
                    OutlinedTextField(
                        value = riskPctText,
                        onValueChange = { riskPctText = it },
                        label = { Text("Risk (%)") },
                        modifier = Modifier.weight(1f).testTag("input_risk_pct"),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = outlinedColors()
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = calcEntryInput,
                        onValueChange = { calcEntryInput = it },
                        label = { Text("Entry Price ($)") },
                        modifier = Modifier.weight(1f).testTag("input_calc_entry"),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = outlinedColors()
                    )
                    OutlinedTextField(
                        value = calcSlInput,
                        onValueChange = { calcSlInput = it },
                        label = { Text("Stop Loss ($)") },
                        modifier = Modifier.weight(1f).testTag("input_calc_sl"),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = outlinedColors()
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Calculated Output Box
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkSurfaceVariant, RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Max Loss Allowed (${riskPercent}%):", color = TextSecondary, fontSize = 11.sp)
                        Text("$${formatNum(maxLossAllowed)}", color = BearishRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Recommended Position Size:", color = TextSecondary, fontSize = 11.sp)
                        Text("$${formatNum(safePositionSizeUsd)}", color = BullishGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Quantity in Crypto:", color = TextSecondary, fontSize = 11.sp)
                        Text(String.format(Locale.US, "%.5f", safeUnits), color = CyanAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 2. Trader Profile & Risk Tolerance
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurface, RoundedCornerShape(12.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(12.dp))
                    .padding(14.dp)
                    .testTag("trader_profile_card")
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = GoldAccent)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Trader Profile & Risk Setting",
                        color = TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = traderName,
                    onValueChange = { traderName = it },
                    label = { Text("Trader Name") },
                    modifier = Modifier.fillMaxWidth().testTag("input_trader_name"),
                    colors = outlinedColors()
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text("Risk Tolerance Category:", color = TextSecondary, fontSize = 11.sp)
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Conservative", "Moderate", "Aggressive").forEach { risk ->
                        val isSelected = selectedRisk == risk
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(
                                    if (isSelected) GoldAccent else DarkSurfaceVariant,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { selectedRisk = risk }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = risk,
                                color = if (isSelected) DarkBg else TextSecondary,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = {
                        val pct = riskPctText.toDoubleOrNull() ?: 1.5
                        onUpdateProfile(traderName, profile.experienceLevel, selectedRisk, pct)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = Color.Black),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().testTag("btn_save_profile")
                ) {
                    Text("Settings Save Karein", fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun outlinedColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = CyanAccent,
    unfocusedBorderColor = DarkBorder,
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextPrimary,
    focusedLabelColor = CyanAccent,
    unfocusedLabelColor = TextSecondary,
    cursorColor = CyanAccent
)

private fun formatNum(num: Double): String {
    return if (num >= 100) {
        String.format(Locale.US, "%,.2f", num)
    } else {
        String.format(Locale.US, "%,.4f", num)
    }
}
