package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TechnicalIndicators
import com.example.ui.theme.BearishRed
import com.example.ui.theme.BullishGreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.Ema21Color
import com.example.ui.theme.Ema9Color
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.NeutralYellow
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VwapColor
import java.util.Locale

@Composable
fun IndicatorsGrid(
    indicators: TechnicalIndicators,
    currentPrice: Double,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("indicators_grid_container")
    ) {
        Text(
            text = "Technical Indicators (Real Time Quantitative):",
            color = CyanAccent,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        // Row 1: EMA 9 & EMA 21
        val ema9 = indicators.ema9
        val ema21 = indicators.ema21
        val emaBullish = ema9 != null && ema21 != null && ema9 > ema21
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            IndicatorCard(
                title = "EMA 9 & EMA 21",
                value = "9: $${formatNum(ema9)} | 21: $${formatNum(ema21)}",
                status = if (emaBullish) "Bullish Trend" else "Bearish / Flat",
                statusColor = if (emaBullish) BullishGreen else BearishRed,
                hinglishNote = if (emaBullish) "EMA 9 upar trade kar raha hai" else "EMA 9 neeche chal raha hai",
                modifier = Modifier.weight(1f),
                testTag = "indicator_ema"
            )

            // RSI 14
            val rsi = indicators.rsi14
            val rsiStatus = when {
                rsi == null -> "Calculating"
                rsi > 70 -> "Overbought"
                rsi < 30 -> "Oversold"
                rsi in 50.0..70.0 -> "Bullish Momentum"
                else -> "Bearish Pressure"
            }
            val rsiColor = when {
                rsi == null -> TextMuted
                rsi > 70 -> BearishRed
                rsi < 30 -> BullishGreen
                rsi in 50.0..70.0 -> BullishGreen
                else -> NeutralYellow
            }
            IndicatorCard(
                title = "RSI 14",
                value = if (rsi != null) String.format(Locale.US, "%.1f", rsi) else "--",
                status = rsiStatus,
                statusColor = rsiColor,
                hinglishNote = when {
                    rsi == null -> "Data aane ka intezar hai"
                    rsi > 70 -> "Thoda savdhan: Overbought"
                    rsi < 30 -> "Bounce back sambhav: Oversold"
                    rsi in 50.0..70.0 -> "Buyers active hain"
                    else -> "Sellers dominant hain"
                },
                modifier = Modifier.weight(1f),
                testTag = "indicator_rsi"
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Row 2: MACD 12/26/9 & VWAP
        val macdHist = indicators.macdHistogram
        val macdLine = indicators.macdLine
        val macdSignal = indicators.macdSignal
        val macdBullish = macdHist != null && macdHist > 0

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            IndicatorCard(
                title = "MACD (12/26/9)",
                value = if (macdHist != null) "Hist: ${formatNum(macdHist)}" else "--",
                status = if (macdBullish) "Positive Histogram" else "Negative Histogram",
                statusColor = if (macdBullish) BullishGreen else BearishRed,
                hinglishNote = if (macdBullish) "Green bars: Buyers strong" else "Red bars: Selling pressure",
                modifier = Modifier.weight(1f),
                testTag = "indicator_macd"
            )

            val vwap = indicators.vwap
            val isAboveVwap = vwap != null && currentPrice >= vwap
            IndicatorCard(
                title = "VWAP",
                value = if (vwap != null) "$${formatNum(vwap)}" else "--",
                status = if (isAboveVwap) "Price > VWAP" else "Price < VWAP",
                statusColor = if (isAboveVwap) BullishGreen else BearishRed,
                hinglishNote = if (isAboveVwap) "Institutional support upar hai" else "Resistance ke neeche trade",
                modifier = Modifier.weight(1f),
                testTag = "indicator_vwap"
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Row 3: ATR 14 (Full Width)
        val atr = indicators.atr14
        IndicatorCard(
            title = "ATR 14 (Average True Range - Volatility)",
            value = if (atr != null) "$${formatNum(atr)} (1m Volatility Range)" else "--",
            status = "SL & Target Dynamic Anchor",
            statusColor = CyanAccent,
            hinglishNote = "Har signal ka Stop Loss aur Target is ATR ($${formatNum(atr)}) ke 1.5x / 3x par set hota hai.",
            modifier = Modifier.fillMaxWidth(),
            testTag = "indicator_atr"
        )
    }
}

@Composable
private fun IndicatorCard(
    title: String,
    value: String,
    status: String,
    statusColor: Color,
    hinglishNote: String,
    modifier: Modifier = Modifier,
    testTag: String
) {
    Column(
        modifier = modifier
            .background(DarkSurface, RoundedCornerShape(10.dp))
            .border(1.dp, DarkBorder, RoundedCornerShape(10.dp))
            .padding(10.dp)
            .testTag(testTag)
    ) {
        Text(
            text = title,
            color = TextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = value,
            color = TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(3.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .background(statusColor.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = status,
                    color = statusColor,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = hinglishNote,
            color = TextMuted,
            fontSize = 10.sp,
            lineHeight = 13.sp
        )
    }
}

private fun formatNum(num: Double?): String {
    if (num == null) return "--"
    return if (Math.abs(num) >= 100) {
        String.format(Locale.US, "%.2f", num)
    } else {
        String.format(Locale.US, "%.4f", num)
    }
}
