package com.example.ui.viewmodel

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.SmartTradeApp
import com.example.data.auth.TraderProfile
import com.example.data.model.Candle
import com.example.data.model.MarketPair
import com.example.data.model.TechnicalIndicators
import com.example.data.model.Ticker24h
import com.example.data.model.Timeframe
import com.example.data.model.TradeSignal
import com.example.domain.ocr.OcrScanResult
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TradingViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as SmartTradeApp).tradingRepository
    private val authManager = (application as SmartTradeApp).authManager

    val selectedPair: StateFlow<MarketPair> = repository.selectedPair
    val selectedTimeframe: StateFlow<Timeframe> = repository.selectedTimeframe
    val ticker: StateFlow<Ticker24h?> = repository.currentTicker
    val candles: StateFlow<List<Candle>> = repository.currentCandles
    val indicators: StateFlow<TechnicalIndicators> = repository.currentIndicators
    val signal: StateFlow<TradeSignal?> = repository.currentSignal
    val isLoading: StateFlow<Boolean> = repository.isLoading
    val errorMessage: StateFlow<String?> = repository.errorMessage
    val isScanningActive: StateFlow<Boolean> = repository.isContinuousScanning
    val ocrLastResult: StateFlow<OcrScanResult?> = repository.ocrLastResult

    val traderProfile: StateFlow<TraderProfile> = authManager.currentProfile

    val signalHistory: StateFlow<List<TradeSignal>> = repository.signalHistory
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun selectPair(pair: MarketPair) {
        repository.selectPair(pair)
    }

    fun selectTimeframe(tf: Timeframe) {
        repository.selectTimeframe(tf)
    }

    fun refresh() {
        repository.refreshMarketData()
    }

    fun deleteSignal(id: Long) {
        repository.deleteSignal(id)
    }

    fun clearAllSignals() {
        repository.clearSignalHistory()
    }

    fun startScan() {
        repository.setContinuousScanning(true)
    }

    fun stopScan() {
        repository.setContinuousScanning(false)
    }

    fun pauseScan() {
        repository.setContinuousScanning(false)
    }

    suspend fun runDirectOcrTest(bitmap: Bitmap): OcrScanResult {
        return repository.analyzeScreenBitmap(bitmap)
    }

    fun updateProfile(name: String, exp: String, risk: String, riskPct: Double) {
        authManager.updateProfile(name, exp, risk, riskPct)
    }
}
