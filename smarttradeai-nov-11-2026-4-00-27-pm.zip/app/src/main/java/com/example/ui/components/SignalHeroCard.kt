package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SignalType
import com.example.data.model.TradeSignal
import com.example.ui.theme.BearishRed
import com.example.ui.theme.BearishRedBg
import com.example.ui.theme.BullishGreen
import com.example.ui.theme.BullishGreenBg
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.NeutralYellow
import com.example.ui.theme.NeutralYellowBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SignalHeroCard(
    signal: TradeSignal?,
    modifier: Modifier = Modifier
) {
    if (signal == null) {
        Card(
            modifier = modifier
                .fillMaxWidth()
                .testTag("signal_hero_card_empty"),
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            shape = RoundedCornerShape(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Signals calculate ho rahe hain...",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
            }
        }
        return
    }

    val isBuy = signal.type == SignalType.BUY
    val isSell = signal.type == SignalType.SELL
    val isNeutral = signal.type == SignalType.NEUTRAL

    val primaryColor = when {
        isBuy -> BullishGreen
        isSell -> BearishRed
        else -> NeutralYellow
    }

    val badgeBg = when {
        isBuy -> BullishGreenBg
        isSell -> BearishRedBg
        else -> NeutralYellowBg
    }

    val borderColor = when {
        isBuy -> BullishGreen.copy(alpha = 0.4f)
        isSell -> BearishRed.copy(alpha = 0.4f)
        else -> DarkBorder
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, borderColor, RoundedCornerShape(12.dp))
            .testTag("signal_hero_card"),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Top Row: Badge, Pair, Timeframe, Timestamp
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .background(badgeBg, RoundedCornerShape(6.dp))
                        .border(1.dp, primaryColor, RoundedCornerShape(6.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                        .testTag("signal_type_badge"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = when {
                                isBuy -> Icons.Default.ArrowUpward
                                isSell -> Icons.Default.ArrowDownward
                                else -> Icons.Default.Info
                            },
                            contentDescription = signal.type.name,
                            tint = primaryColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = signal.type.titleHinglish,
                            color = primaryColor,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.weight(1f))

                Text(
                    text = "${signal.pair} • ${signal.timeframe}",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Price Targets Grid
            if (!isNeutral) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkSurfaceVariant, RoundedCornerShape(8.dp))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TargetColumn(
                        label = "Entry Price",
                        value = "$${formatNum(signal.entryPrice)}",
                        valueColor = TextPrimary,
                        testTag = "target_entry"
                    )
                    TargetColumn(
                        label = "Stop Loss (SL)",
                        value = "$${formatNum(signal.stopLoss)}",
                        valueColor = BearishRed,
                        testTag = "target_sl"
                    )
                    TargetColumn(
                        label = "Target 1 (1:1)",
                        value = "$${formatNum(signal.target1)}",
                        valueColor = BullishGreen,
                        testTag = "target_t1"
                    )
                    TargetColumn(
                        label = "Target 2 (1:2)",
                        value = "$${formatNum(signal.target2)}",
                        valueColor = CyanAccent,
                        testTag = "target_t2"
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkSurfaceVariant, RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Text(
                        text = "Current Live Price: $${formatNum(signal.entryPrice)} • Market me clear direction aane tak nayi position na banayein.",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
                Spacer(modifier = Modifier.height(14.dp))
            }

            // Reasons Header
            Text(
                text = "Kyun Mila Ye Signal? (Analysis Reasons):",
                color = GoldAccent,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Bulleted Reasons in Hinglish
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("signal_reasons_list")
            ) {
                signal.reasons.forEach { reason ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(
                            text = "•",
                            color = primaryColor,
                            fontSize = 14.sp,
                            modifier = Modifier.padding(end = 6.dp)
                        )
                        Text(
                            text = reason,
                            color = TextPrimary,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Source & Timestamp footer
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val timeFormat = SimpleDateFormat("hh:mm:ss a, dd MMM", Locale.getDefault())
                val timeStr = timeFormat.format(Date(signal.timestamp))

                Text(
                    text = "Source: ${if (signal.source == "SCREEN_OCR") "Screen OCR Scan" else "Live Exchange Engine"}",
                    color = TextMuted,
                    fontSize = 10.sp
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = timeStr,
                    color = TextMuted,
                    fontSize = 10.sp
                )
            }
        }
    }
}

@Composable
private fun TargetColumn(
    label: String,
    value: String,
    valueColor: Color,
    testTag: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.testTag(testTag)
    ) {
        Text(
            text = label,
            color = TextSecondary,
            fontSize = 10.sp,
            fontWeight = FontWeight.Normal
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            color = valueColor,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

private fun formatNum(num: Double): String {
    return if (num >= 100) {
        String.format(Locale.US, "%,.2f", num)
    } else {
        String.format(Locale.US, "%,.4f", num)
    }
}
