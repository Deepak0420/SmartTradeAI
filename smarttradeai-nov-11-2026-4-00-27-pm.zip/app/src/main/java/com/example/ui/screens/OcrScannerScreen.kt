package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.ocr.OcrScanResult
import com.example.ui.theme.BearishRed
import com.example.ui.theme.BullishGreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.NeutralYellow
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OcrScannerScreen(
    lastOcrResult: OcrScanResult?,
    isScanningActive: Boolean,
    onStartScan: () -> Unit,
    onStopScan: () -> Unit,
    onPauseScan: () -> Unit,
    onRunDirectOcrTest: suspend (Bitmap) -> Unit,
    onRequestMediaProjection: () -> Unit,
    hasOverlayPermission: Boolean,
    onRequestOverlayPermission: () -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    var isTestingOcr by remember { mutableStateOf(false) }
    var testFeedback by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CameraAlt,
                            contentDescription = null,
                            tint = CyanAccent,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Screen OCR & Assistant",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = TextPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkSurface,
                    titleContentColor = TextPrimary
                )
            )
        },
        containerColor = DarkBg,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(14.dp)
                .testTag("ocr_scanner_screen_content")
        ) {
            // Scanner Status Header Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurface, RoundedCornerShape(12.dp))
                    .border(1.dp, if (isScanningActive) BullishGreen else DarkBorder, RoundedCornerShape(12.dp))
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .background(
                                if (isScanningActive) BullishGreen.copy(alpha = 0.2f) else DarkSurfaceVariant,
                                RoundedCornerShape(6.dp)
                            )
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (isScanningActive) "SCANNING ACTIVE (Chalu)" else "SCANNER IDLE (Band)",
                            color = if (isScanningActive) BullishGreen else TextSecondary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                    Spacer(modifier = Modifier.weight(1f))
                    Text(
                        text = "Google ML Kit OCR",
                        color = CyanAccent,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Continuous Scan Controls:",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Screen par visible chart symbols aur live prices detect karke assistant live recommendations provide karta hai.",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 15.sp,
                    modifier = Modifier.padding(top = 2.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Three core buttons: Start Scan, Pause, Stop Scan
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onStartScan,
                        colors = ButtonDefaults.buttonColors(containerColor = BullishGreen, contentColor = Color.Black),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_ocr_start_scan")
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Start Scan", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = onPauseScan,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = NeutralYellow),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_ocr_pause_scan")
                    ) {
                        Icon(imageVector = Icons.Default.Pause, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Pause", fontSize = 11.sp)
                    }

                    OutlinedButton(
                        onClick = onStopScan,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = BearishRed),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_ocr_stop_scan")
                    ) {
                        Icon(imageVector = Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Stop", fontSize = 11.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Last Scan Detection Results Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurface, RoundedCornerShape(12.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(12.dp))
                    .padding(14.dp)
                    .testTag("ocr_results_card")
            ) {
                Text(
                    text = "Screen Detection Output (ML Kit):",
                    color = CyanAccent,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                if (lastOcrResult == null) {
                    Text(
                        text = "Abhi tak koi screen scan run nahi hua hai. Niche diye gaye button se chart OCR verify karein.",
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DarkSurfaceVariant, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Detected Pair", color = TextMuted, fontSize = 10.sp)
                            Text(
                                text = lastOcrResult.detectedPair?.displayName ?: "Symbol Not Clear",
                                color = if (lastOcrResult.detectedPair != null) BullishGreen else TextSecondary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Detected Price", color = TextMuted, fontSize = 10.sp)
                            Text(
                                text = if (lastOcrResult.detectedPrice != null) "$${lastOcrResult.detectedPrice}" else "Unreadable",
                                color = if (lastOcrResult.detectedPrice != null) CyanAccent else TextSecondary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Timeframe", color = TextMuted, fontSize = 10.sp)
                            Text(
                                text = lastOcrResult.detectedTimeframe ?: "1m (Default)",
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Status: ${lastOcrResult.statusMessageHinglish}",
                        color = if (lastOcrResult.isSuccess) BullishGreen else NeutralYellow,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )

                    if (lastOcrResult.recognizedIndicators.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Visible Indicators: ${lastOcrResult.recognizedIndicators.joinToString(", ")}",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Instant Test OCR Engine Button
                Button(
                    onClick = {
                        isTestingOcr = true
                        testFeedback = "ML Kit engine reading simulated TradingView BTC/USDT chart frame..."
                        coroutineScope.launch {
                            val testBitmap = createSampleChartBitmap()
                            onRunDirectOcrTest(testBitmap)
                            isTestingOcr = false
                            testFeedback = "OCR test complete! Live engine reconciled detected price."
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyanAccent, contentColor = Color.Black),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_run_test_ocr")
                ) {
                    if (isTestingOcr) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.Black, strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                    Text("🧪 Test ML Kit OCR Engine (Verify Now)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                if (testFeedback != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = testFeedback!!, color = GoldAccent, fontSize = 11.sp)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Trading Application Compatibility Guide
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurface, RoundedCornerShape(12.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(12.dp))
                    .padding(14.dp)
            ) {
                Text(
                    text = "App Compatibility Guide:",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                CompatibilityGuideItem("TradingView Mobile", "Full candle & price axis compatibility. EMA and RSI text auto-detected.")
                CompatibilityGuideItem("Binance App", "Spot & Futures chart candlestick support. Real-time ticker reading.")
                CompatibilityGuideItem("CoinDCX / WazirX", "INR & USDT market pairs supported.")
                CompatibilityGuideItem("Delta Exchange", "Crypto options & futures chart reading.")
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun CompatibilityGuideItem(appName: String, desc: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top
    ) {
        Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            tint = BullishGreen,
            modifier = Modifier.size(16.dp).padding(top = 2.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Text(text = appName, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(text = desc, color = TextSecondary, fontSize = 10.sp, lineHeight = 13.sp)
        }
    }
}

// Generates a clean synthetic TradingView test frame with high contrast text for testing ML Kit locally
private fun createSampleChartBitmap(): Bitmap {
    val bitmap = Bitmap.createBitmap(600, 400, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    canvas.drawColor(AndroidColor.parseColor("#131A26"))

    val paint = Paint().apply {
        isAntiAlias = true
        color = AndroidColor.WHITE
        textSize = 32f
    }
    canvas.drawText("BINANCE: BTCUSDT  1m", 40f, 60f, paint)

    paint.color = AndroidColor.parseColor("#00E676")
    paint.textSize = 44f
    canvas.drawText("91,450.50 USDT", 40f, 130f, paint)

    paint.color = AndroidColor.parseColor("#00E5FF")
    paint.textSize = 26f
    canvas.drawText("EMA(9): 91,280.00  EMA(21): 90,950.00", 40f, 200f, paint)

    paint.color = AndroidColor.parseColor("#FFD600")
    canvas.drawText("RSI(14): 58.40  VWAP: 91,120.00", 40f, 260f, paint)

    paint.color = AndroidColor.parseColor("#94A3B8")
    paint.textSize = 22f
    canvas.drawText("MACD(12,26,9): +32.40 [Histogram Positive]", 40f, 320f, paint)

    return bitmap
}
