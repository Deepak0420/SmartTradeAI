package com.example.data.api

import android.util.Log
import com.example.data.model.Candle
import com.example.data.model.Ticker24h
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class MarketApiClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    private val binanceBaseUrl = "https://api.binance.com/api/v3"
    private val binanceBackupUrl = "https://data-api.binance.vision/api/v3"

    suspend fun fetch24hTicker(symbol: String): Result<Ticker24h> = withContext(Dispatchers.IO) {
        val urls = listOf(
            "$binanceBaseUrl/ticker/24hr?symbol=$symbol",
            "$binanceBackupUrl/ticker/24hr?symbol=$symbol"
        )

        for (url in urls) {
            try {
                val request = Request.Builder()
                    .url(url)
                    .header("User-Agent", "SmartTradeAI-Android/1.0")
                    .build()

                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string() ?: return@use
                        val json = JSONObject(body)
                        val ticker = Ticker24h(
                            symbol = json.optString("symbol", symbol),
                            lastPrice = json.optDouble("lastPrice", 0.0),
                            priceChangePercent = json.optDouble("priceChangePercent", 0.0),
                            highPrice = json.optDouble("highPrice", 0.0),
                            lowPrice = json.optDouble("lowPrice", 0.0),
                            volume = json.optDouble("volume", 0.0)
                        )
                        return@withContext Result.success(ticker)
                    }
                }
            } catch (e: Exception) {
                Log.w("MarketApiClient", "Ticker fetch failed for $url: ${e.message}")
            }
        }

        // Alternative public exchange fallback if Binance endpoint is throttled
        try {
            val fallbackResult = fetchKuCoinFallbackTicker(symbol)
            if (fallbackResult != null) {
                return@withContext Result.success(fallbackResult)
            }
        } catch (e: Exception) {
            Log.e("MarketApiClient", "Fallback ticker fetch failed: ${e.message}")
        }

        Result.failure(Exception("Market live price connect nahi ho pa raha. Kripya internet connection check karein."))
    }

    suspend fun fetchKlines(symbol: String, interval: String, limit: Int = 100): Result<List<Candle>> =
        withContext(Dispatchers.IO) {
            val urls = listOf(
                "$binanceBaseUrl/klines?symbol=$symbol&interval=$interval&limit=$limit",
                "$binanceBackupUrl/klines?symbol=$symbol&interval=$interval&limit=$limit"
            )

            for (url in urls) {
                try {
                    val request = Request.Builder()
                        .url(url)
                        .header("User-Agent", "SmartTradeAI-Android/1.0")
                        .build()

                    client.newCall(request).execute().use { response ->
                        if (response.isSuccessful) {
                            val body = response.body?.string() ?: return@use
                            val jsonArray = JSONArray(body)
                            val candles = mutableListOf<Candle>()

                            for (i in 0 until jsonArray.length()) {
                                val item = jsonArray.getJSONArray(i)
                                val openTime = item.getLong(0)
                                val open = item.getString(1).toDoubleOrNull() ?: 0.0
                                val high = item.getString(2).toDoubleOrNull() ?: 0.0
                                val low = item.getString(3).toDoubleOrNull() ?: 0.0
                                val close = item.getString(4).toDoubleOrNull() ?: 0.0
                                val volume = item.getString(5).toDoubleOrNull() ?: 0.0
                                val closeTime = item.getLong(6)

                                candles.add(
                                    Candle(
                                        openTime = openTime,
                                        open = open,
                                        high = high,
                                        low = low,
                                        close = close,
                                        volume = volume,
                                        closeTime = closeTime
                                    )
                                )
                            }
                            if (candles.isNotEmpty()) {
                                return@withContext Result.success(candles)
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.w("MarketApiClient", "Klines fetch failed for $url: ${e.message}")
                }
            }

            Result.failure(Exception("Klines data prapt nahi ho saka. Connection retry ho raha hai..."))
        }

    private fun fetchKuCoinFallbackTicker(binanceSymbol: String): Ticker24h? {
        val kucoinPair = when (binanceSymbol) {
            "BTCUSDT" -> "BTC-USDT"
            "ETHUSDT" -> "ETH-USDT"
            else -> return null
        }
        val request = Request.Builder()
            .url("https://api.kucoin.com/api/v1/market/orderbook/level1?symbol=$kucoinPair")
            .header("User-Agent", "SmartTradeAI-Android/1.0")
            .build()

        client.newCall(request).execute().use { response ->
            if (response.isSuccessful) {
                val body = response.body?.string() ?: return null
                val root = JSONObject(body)
                val data = root.optJSONObject("data") ?: return null
                val price = data.optDouble("price", 0.0)
                if (price > 0.0) {
                    return Ticker24h(
                        symbol = binanceSymbol,
                        lastPrice = price,
                        priceChangePercent = 0.0,
                        highPrice = price,
                        lowPrice = price,
                        volume = 0.0
                    )
                }
            }
        }
        return null
    }
}
