package com.example.domain.engine

import com.example.data.model.Candle
import com.example.data.model.SignalType
import com.example.data.model.TechnicalIndicators
import com.example.data.model.TradeSignal
import java.util.Locale
import kotlin.math.roundToInt

object SignalGenerator {

    fun generateSignal(
        pair: String,
        timeframe: String,
        currentPrice: Double,
        candles: List<Candle>,
        indicators: TechnicalIndicators,
        source: String = "LIVE_API"
    ): TradeSignal {
        if (candles.size < 30 || currentPrice <= 0.0) {
            return TradeSignal(
                pair = pair,
                timeframe = timeframe,
                type = SignalType.NEUTRAL,
                entryPrice = currentPrice,
                stopLoss = 0.0,
                target1 = 0.0,
                target2 = 0.0,
                riskRewardRatio = 0.0,
                reasons = listOf("Paryapt market data ikattha ho raha hai... Kripya thoda intezar karein."),
                source = source
            )
        }

        val ema9 = indicators.ema9 ?: currentPrice
        val ema21 = indicators.ema21 ?: currentPrice
        val rsi = indicators.rsi14 ?: 50.0
        val macdHist = indicators.macdHistogram ?: 0.0
        val macdLine = indicators.macdLine ?: 0.0
        val macdSignal = indicators.macdSignal ?: 0.0
        val vwap = indicators.vwap ?: currentPrice
        val atr = indicators.atr14 ?: (currentPrice * 0.005)

        val buyReasons = mutableListOf<String>()
        val sellReasons = mutableListOf<String>()
        val neutralReasons = mutableListOf<String>()

        var bullishPoints = 0
        var bearishPoints = 0

        // 1. EMA 9 vs EMA 21
        if (ema9 > ema21) {
            bullishPoints++
            buyReasons.add("EMA 9 (${formatVal(ema9)}) ne EMA 21 (${formatVal(ema21)}) ke upar cross kiya hai (Bullish Trend).")
        } else if (ema9 < ema21) {
            bearishPoints++
            sellReasons.add("EMA 9 (${formatVal(ema9)}) EMA 21 (${formatVal(ema21)}) ke neeche hai (Bearish Downward Pressure).")
        } else {
            neutralReasons.add("EMA 9 aur EMA 21 flat hain, trend abhi decide ho raha hai.")
        }

        // 2. RSI 14
        if (rsi in 45.0..70.0) {
            bullishPoints++
            buyReasons.add("RSI 14 = ${formatVal(rsi)}, jo strong bullish momentum dikha raha hai (Overbought nahi hai).")
        } else if (rsi in 30.0..55.0) {
            bearishPoints++
            sellReasons.add("RSI 14 = ${formatVal(rsi)}, sellers active hain aur price par downward pressure hai.")
        } else if (rsi > 70.0) {
            neutralReasons.add("RSI 14 (${formatVal(rsi)}) Overbought zone me hai! Nayi buying me pullback ka risk hai.")
        } else if (rsi < 30.0) {
            neutralReasons.add("RSI 14 (${formatVal(rsi)}) Oversold zone me hai, bounce back ho sakta hai.")
        }

        // 3. MACD 12/26/9
        if (macdHist > 0.0 || macdLine > macdSignal) {
            bullishPoints++
            buyReasons.add("MACD Histogram positive green zone me hai (${formatVal(macdHist)}), buyers ka zor zyada hai.")
        } else if (macdHist < 0.0 || macdLine < macdSignal) {
            bearishPoints++
            sellReasons.add("MACD Histogram negative red zone me hai (${formatVal(macdHist)}), selling volume badh raha hai.")
        }

        // 4. VWAP
        if (currentPrice >= vwap) {
            bullishPoints++
            buyReasons.add("Live price VWAP (${formatVal(vwap)}) ke upar sustain kar raha hai (Institutional buyers active).")
        } else {
            bearishPoints++
            sellReasons.add("Live price VWAP (${formatVal(vwap)}) ke neeche slip ho chuka hai (Resistance zone).")
        }

        // ATR based calculation for Stop Loss and Targets
        val safeAtr = if (atr <= 0.0) currentPrice * 0.005 else atr

        return when {
            bullishPoints >= 3 -> {
                val sl = currentPrice - (1.5 * safeAtr)
                val t1 = currentPrice + (1.5 * safeAtr)
                val t2 = currentPrice + (3.0 * safeAtr)
                TradeSignal(
                    pair = pair,
                    timeframe = timeframe,
                    type = SignalType.BUY,
                    entryPrice = currentPrice,
                    stopLoss = sl,
                    target1 = t1,
                    target2 = t2,
                    riskRewardRatio = 2.0,
                    reasons = buyReasons,
                    source = source
                )
            }
            bearishPoints >= 3 -> {
                val sl = currentPrice + (1.5 * safeAtr)
                val t1 = currentPrice - (1.5 * safeAtr)
                val t2 = currentPrice - (3.0 * safeAtr)
                TradeSignal(
                    pair = pair,
                    timeframe = timeframe,
                    type = SignalType.SELL,
                    entryPrice = currentPrice,
                    stopLoss = sl,
                    target1 = t1,
                    target2 = t2,
                    riskRewardRatio = 2.0,
                    reasons = sellReasons,
                    source = source
                )
            }
            else -> {
                val combinedReasons = mutableListOf<String>()
                combinedReasons.add("Market abhi range-bound / consolidation phase me hai.")
                if (neutralReasons.isNotEmpty()) {
                    combinedReasons.addAll(neutralReasons)
                } else {
                    combinedReasons.add("Indicators me mixed signals hain (Bullish $bullishPoints/4, Bearish $bearishPoints/4).")
                    combinedReasons.add("Clear confirmation aur volume breakout ka intezar karein.")
                }
                TradeSignal(
                    pair = pair,
                    timeframe = timeframe,
                    type = SignalType.NEUTRAL,
                    entryPrice = currentPrice,
                    stopLoss = 0.0,
                    target1 = 0.0,
                    target2 = 0.0,
                    riskRewardRatio = 0.0,
                    reasons = combinedReasons,
                    source = source
                )
            }
        }
    }

    private fun formatVal(value: Double): String {
        return if (value >= 100) {
            String.format(Locale.US, "%.2f", value)
        } else {
            String.format(Locale.US, "%.4f", value)
        }
    }
}
