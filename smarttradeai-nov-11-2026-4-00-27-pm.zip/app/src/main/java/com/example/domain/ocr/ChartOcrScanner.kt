package com.example.domain.ocr

import android.graphics.Bitmap
import android.util.Log
import com.example.data.model.MarketPair
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import java.util.regex.Pattern
import kotlin.coroutines.resume

data class OcrScanResult(
    val isSuccess: Boolean,
    val detectedPair: MarketPair?,
    val detectedPrice: Double?,
    val detectedTimeframe: String?,
    val recognizedIndicators: List<String>,
    val rawTextSnippet: String,
    val statusMessageHinglish: String
)

class ChartOcrScanner {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private val pricePattern = Pattern.compile("(?i)(?:USD[T]?|[$])?\\s*([0-9]{1,3}(?:,[0-9]{3})+(?:\\.[0-9]+)?|[0-9]{3,6}(?:\\.[0-9]+)?)")
    private val timeframePattern = Pattern.compile("(?i)\\b(1m|3m|5m|15m|30m|1h|4h|1d|1D)\\b")

    suspend fun analyzeChartBitmap(bitmap: Bitmap): OcrScanResult =
        suspendCancellableCoroutine { continuation ->
            try {
                val inputImage = InputImage.fromBitmap(bitmap, 0)
                recognizer.process(inputImage)
                    .addOnSuccessListener { visionText ->
                        val text = visionText.text
                        val result = parseVisionText(text)
                        continuation.resume(result)
                    }
                    .addOnFailureListener { e ->
                        Log.e("ChartOcrScanner", "ML Kit OCR failed: ${e.message}")
                        continuation.resume(
                            OcrScanResult(
                                isSuccess = false,
                                detectedPair = null,
                                detectedPrice = null,
                                detectedTimeframe = null,
                                recognizedIndicators = emptyList(),
                                rawTextSnippet = "",
                                statusMessageHinglish = "OCR scan me truti aayi: ${e.localizedMessage ?: "Unknown error"}"
                            )
                        )
                    }
            } catch (e: Exception) {
                continuation.resume(
                    OcrScanResult(
                        isSuccess = false,
                        detectedPair = null,
                        detectedPrice = null,
                        detectedTimeframe = null,
                        recognizedIndicators = emptyList(),
                        rawTextSnippet = "",
                        statusMessageHinglish = "Chart image process nahi ho saki: ${e.localizedMessage ?: "Error"}"
                    )
                )
            }
        }

    private fun parseVisionText(text: String): OcrScanResult {
        if (text.isBlank()) {
            return OcrScanResult(
                isSuccess = false,
                detectedPair = null,
                detectedPrice = null,
                detectedTimeframe = null,
                recognizedIndicators = emptyList(),
                rawTextSnippet = "",
                statusMessageHinglish = "Screen par koi chart text detect nahi hua. TradingView ya exchange app open karein."
            )
        }

        val upper = text.uppercase(Locale.US)

        // 1. Detect Symbol
        var detectedPair: MarketPair? = null
        if (upper.contains("BTC") || upper.contains("BITCOIN")) {
            detectedPair = MarketPair.BTC_USDT
        } else if (upper.contains("ETH") || upper.contains("ETHEREUM")) {
            detectedPair = MarketPair.ETH_USDT
        }

        // 2. Detect Timeframe
        var detectedTf: String? = null
        val tfMatcher = timeframePattern.matcher(text)
        if (tfMatcher.find()) {
            detectedTf = tfMatcher.group(1)
        }

        // 3. Detect Indicators
        val indicators = mutableListOf<String>()
        if (upper.contains("EMA") || upper.contains("EXPONENTIAL")) indicators.add("EMA")
        if (upper.contains("RSI") || upper.contains("RELATIVE STRENGTH")) indicators.add("RSI")
        if (upper.contains("MACD")) indicators.add("MACD")
        if (upper.contains("VWAP")) indicators.add("VWAP")
        if (upper.contains("ATR") || upper.contains("AVERAGE TRUE")) indicators.add("ATR")
        if (upper.contains("VOL") || upper.contains("VOLUME")) indicators.add("Volume")

        // 4. Detect Prices
        val prices = mutableListOf<Double>()
        val matcher = pricePattern.matcher(text)
        while (matcher.find()) {
            val numStr = matcher.group(1)?.replace(",", "")
            val parsed = numStr?.toDoubleOrNull()
            if (parsed != null) {
                // Filter realistic crypto ranges (e.g. BTC ~ 10,000 - 200,000, ETH ~ 500 - 20,000)
                if (detectedPair == MarketPair.BTC_USDT && parsed in 10000.0..300000.0) {
                    prices.add(parsed)
                } else if (detectedPair == MarketPair.ETH_USDT && parsed in 500.0..30000.0) {
                    prices.add(parsed)
                } else if (detectedPair == null && parsed in 500.0..300000.0) {
                    prices.add(parsed)
                }
            }
        }

        val detectedPrice = prices.firstOrNull()

        val isSuccess = detectedPair != null || detectedPrice != null
        val snippet = text.lines().filter { it.isNotBlank() }.take(5).joinToString(" | ")

        val message = when {
            detectedPair != null && detectedPrice != null ->
                "${detectedPair.displayName} chart detect hua! Live OCR Price: $${detectedPrice}. Timeframe: ${detectedTf ?: "1m"}."
            detectedPair != null ->
                "${detectedPair.displayName} chart mil gaya, kintu live price numbers thode blur hain. Live API data use kiya ja raha hai."
            detectedPrice != null ->
                "Price detect hui: $${detectedPrice}. Trading pair confirm karne ke liye chart symbol dikhayein."
            else ->
                "Chart values clear nahi dikh rahe hain. Screen par chart aur price numbers ko spashth rakhein."
        }

        return OcrScanResult(
            isSuccess = isSuccess,
            detectedPair = detectedPair,
            detectedPrice = detectedPrice,
            detectedTimeframe = detectedTf,
            recognizedIndicators = indicators,
            rawTextSnippet = snippet,
            statusMessageHinglish = message
        )
    }
}
