package com.example.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.SmartTradeApp
import com.example.data.model.SignalType
import com.example.data.model.TradeSignal
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import java.util.Locale

class FloatingAssistantService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var continuousScanJob: Job? = null

    private var isExpanded = false
    private var isScanningActive = false
    private var isPaused = false

    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForegroundServiceNotification()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action

        when (action) {
            ACTION_STOP_SERVICE -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START_PROJECTION -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val resultData = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_RESULT_DATA)
                }

                if (resultCode != 0 && resultData != null) {
                    initMediaProjection(resultCode, resultData)
                }
            }
        }

        if (Settings.canDrawOverlays(this)) {
            if (floatingView == null) {
                initFloatingOverlay()
            }
        }

        observeRepository()
        return START_STICKY
    }

    private fun startForegroundServiceNotification() {
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            notificationIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, FloatingAssistantService::class.java).apply {
            action = ACTION_STOP_SERVICE
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, SmartTradeApp.NOTIFICATION_CHANNEL_ID)
            .setContentTitle("SmartTradeAI Floating Assistant")
            .setContentText("Trading chart scanner aur overlay sakriya hai.")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Band Karein (Stop)", stopPendingIntent)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                SmartTradeApp.NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(SmartTradeApp.NOTIFICATION_ID, notification)
        }
    }

    private fun initFloatingOverlay() {
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 200
        }

        floatingView = buildOverlayView()
        windowManager?.addView(floatingView, layoutParams)
    }

    private fun buildOverlayView(): View {
        val rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.TRANSPARENT)
            setPadding(8, 8, 8, 8)
        }

        // 1. Minimized Bubble View
        val bubbleLayout = LinearLayout(this).apply {
            tag = "bubble_layout"
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(24, 16, 24, 16)
            background = createBubbleBackground()
        }

        val logoIcon = ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher)
            layoutParams = LinearLayout.LayoutParams(60, 60).apply {
                marginEnd = 16
            }
        }

        val bubbleText = TextView(this).apply {
            tag = "bubble_text"
            text = "SmartTrade AI • Ready"
            setTextColor(Color.WHITE)
            textSize = 13f
        }

        bubbleLayout.addView(logoIcon)
        bubbleLayout.addView(bubbleText)

        // 2. Expanded Card View
        val expandedCard = LinearLayout(this).apply {
            tag = "expanded_card"
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(28, 24, 28, 24)
            background = createCardBackground()
            layoutParams = LinearLayout.LayoutParams(700, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = 12
            }
        }

        // Header
        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val titleText = TextView(this).apply {
            text = "SmartTradeAI Assistant"
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 15f
            paint.isFakeBoldText = true
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val closeBtn = TextView(this).apply {
            text = "✕"
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 16f
            setPadding(12, 4, 12, 4)
            setOnClickListener {
                isExpanded = false
                updateViewState()
            }
        }

        headerRow.addView(titleText)
        headerRow.addView(closeBtn)

        // Status Line
        val statusLine = TextView(this).apply {
            tag = "status_line"
            text = "Status: Scan Band Hai (Tap Start Scan to monitor chart)"
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 11f
            setPadding(0, 8, 0, 8)
        }

        // Signal Box
        val signalBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#1B2436"))
            setPadding(16, 12, 16, 12)
        }

        val signalTitle = TextView(this).apply {
            tag = "signal_title"
            text = "Signal: HOLD / INTEZAR"
            setTextColor(Color.parseColor("#FFD600"))
            textSize = 13f
            paint.isFakeBoldText = true
        }

        val signalDetails = TextView(this).apply {
            tag = "signal_details"
            text = "Entry: -- | SL: -- | T1: -- | T2: --"
            setTextColor(Color.WHITE)
            textSize = 11f
            setPadding(0, 6, 0, 6)
        }

        val signalReason = TextView(this).apply {
            tag = "signal_reason"
            text = "Live chart scan shuru karne ke liye Start Scan press karein."
            setTextColor(Color.parseColor("#CBD5E1"))
            textSize = 11f
        }

        signalBox.addView(signalTitle)
        signalBox.addView(signalDetails)
        signalBox.addView(signalReason)

        // Action Buttons Row: Start Scan, Pause, Stop Scan
        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 16, 0, 8)
        }

        val startBtn = Button(this).apply {
            tag = "btn_start"
            text = "Start Scan"
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.parseColor("#00E676"))
            layoutParams = LinearLayout.LayoutParams(0, 90, 1f).apply {
                marginEnd = 8
            }
            setOnClickListener {
                startContinuousScan()
            }
        }

        val pauseBtn = Button(this).apply {
            tag = "btn_pause"
            text = "Pause"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#475569"))
            layoutParams = LinearLayout.LayoutParams(0, 90, 1f).apply {
                marginEnd = 8
            }
            setOnClickListener {
                togglePauseScan()
            }
        }

        val stopBtn = Button(this).apply {
            tag = "btn_stop"
            text = "Stop"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#FF3D71"))
            layoutParams = LinearLayout.LayoutParams(0, 90, 1f)
            setOnClickListener {
                stopContinuousScan()
            }
        }

        actionRow.addView(startBtn)
        actionRow.addView(pauseBtn)
        actionRow.addView(stopBtn)

        // Instant Scan Now Button
        val scanNowBtn = Button(this).apply {
            text = "📸 Abhi Scan Karein (OCR Scan)"
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.parseColor("#00E5FF"))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 90).apply {
                topMargin = 4
            }
            setOnClickListener {
                captureAndAnalyzeFrameOnce()
            }
        }

        expandedCard.addView(headerRow)
        expandedCard.addView(statusLine)
        expandedCard.addView(signalBox)
        expandedCard.addView(actionRow)
        expandedCard.addView(scanNowBtn)

        rootLayout.addView(bubbleLayout)
        rootLayout.addView(expandedCard)

        // Touch listener for dragging
        setupDragListener(bubbleLayout)

        return rootLayout
    }

    private fun setupDragListener(view: View) {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isClick = true

        view.setOnTouchListener { _, event ->
            val params = layoutParams ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isClick = true
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val deltaX = (event.rawX - initialTouchX).toInt()
                    val deltaY = (event.rawY - initialTouchY).toInt()
                    if (Math.abs(deltaX) > 10 || Math.abs(deltaY) > 10) {
                        isClick = false
                    }
                    params.x = initialX + deltaX
                    params.y = initialY + deltaY
                    windowManager?.updateViewLayout(floatingView, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (isClick) {
                        isExpanded = !isExpanded
                        updateViewState()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun updateViewState() {
        val card = floatingView?.findViewWithTag<View>("expanded_card")
        card?.visibility = if (isExpanded) View.VISIBLE else View.GONE
    }

    private fun observeRepository() {
        val repo = SmartTradeApp.instance.tradingRepository
        serviceScope.launch {
            repo.currentSignal.collect { signal ->
                updateSignalUI(signal)
            }
        }
        serviceScope.launch {
            repo.currentTicker.collect { ticker ->
                if (ticker != null) {
                    val bubbleText = floatingView?.findViewWithTag<TextView>("bubble_text")
                    val priceStr = String.format(Locale.US, "%.2f", ticker.lastPrice)
                    bubbleText?.text = "${ticker.symbol}: $$priceStr"
                }
            }
        }
    }

    private fun updateSignalUI(signal: TradeSignal?) {
        val signalTitle = floatingView?.findViewWithTag<TextView>("signal_title")
        val signalDetails = floatingView?.findViewWithTag<TextView>("signal_details")
        val signalReason = floatingView?.findViewWithTag<TextView>("signal_reason")
        val bubbleText = floatingView?.findViewWithTag<TextView>("bubble_text")

        if (signal == null) return

        val color = when (signal.type) {
            SignalType.BUY -> Color.parseColor("#00E676")
            SignalType.SELL -> Color.parseColor("#FF3D71")
            SignalType.NEUTRAL -> Color.parseColor("#FFD600")
        }

        signalTitle?.text = "${signal.type.titleHinglish} [${signal.pair}]"
        signalTitle?.setTextColor(color)

        if (signal.type != SignalType.NEUTRAL) {
            val entryStr = String.format(Locale.US, "%.2f", signal.entryPrice)
            val slStr = String.format(Locale.US, "%.2f", signal.stopLoss)
            val t1Str = String.format(Locale.US, "%.2f", signal.target1)
            val t2Str = String.format(Locale.US, "%.2f", signal.target2)
            signalDetails?.text = "Entry: $$entryStr | SL: $$slStr\nT1: $$t1Str | T2: $$t2Str"
            bubbleText?.text = "[${signal.type.shortLabel}] ${signal.pair} $$entryStr"
        } else {
            signalDetails?.text = "Market Sideways • No trade trigger"
        }

        signalReason?.text = signal.reasons.firstOrNull() ?: "Market analysis ready."
    }

    private fun initMediaProjection(resultCode: Int, data: Intent) {
        val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = mpManager.getMediaProjection(resultCode, data)

        val metrics = DisplayMetrics()
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getRealMetrics(metrics)

        // Capture scaled down for high performance OCR (720p or half res)
        val width = 720
        val height = 1280
        val density = metrics.densityDpi

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "SmartTradeOcrCapture",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            null
        )
    }

    private fun startContinuousScan() {
        if (mediaProjection == null) {
            updateStatusText("Screen capture permission anuplabdh hai. App se Start karein.")
            return
        }
        isScanningActive = true
        isPaused = false
        SmartTradeApp.instance.tradingRepository.setContinuousScanning(true)
        updateStatusText("Continuous Scan: CHALU HAI (Har 4 second scan ho raha hai)")

        continuousScanJob?.cancel()
        continuousScanJob = serviceScope.launch {
            while (isActive && isScanningActive) {
                if (!isPaused) {
                    captureAndAnalyzeFrameOnce()
                }
                delay(4000)
            }
        }
    }

    private fun togglePauseScan() {
        isPaused = !isPaused
        val pauseBtn = floatingView?.findViewWithTag<Button>("btn_pause")
        if (isPaused) {
            pauseBtn?.text = "Resume"
            updateStatusText("Continuous Scan: RUKA HUA HAI (Paused)")
        } else {
            pauseBtn?.text = "Pause"
            updateStatusText("Continuous Scan: DUBARA CHALU")
        }
    }

    private fun stopContinuousScan() {
        isScanningActive = false
        isPaused = false
        continuousScanJob?.cancel()
        continuousScanJob = null
        SmartTradeApp.instance.tradingRepository.setContinuousScanning(false)
        updateStatusText("Continuous Scan: BAND HAI")
    }

    private fun captureAndAnalyzeFrameOnce() {
        val reader = imageReader ?: return
        serviceScope.launch(Dispatchers.IO) {
            try {
                val image = reader.acquireLatestImage()
                if (image != null) {
                    val planes = image.planes
                    val buffer: ByteBuffer = planes[0].buffer
                    val pixelStride = planes[0].pixelStride
                    val rowStride = planes[0].rowStride
                    val rowPadding = rowStride - pixelStride * image.width

                    val bitmap = Bitmap.createBitmap(
                        image.width + rowPadding / pixelStride,
                        image.height,
                        Bitmap.Config.ARGB_8888
                    )
                    bitmap.copyPixelsFromBuffer(buffer)
                    image.close()

                    // Crop to center chart region
                    val cropped = Bitmap.createBitmap(bitmap, 0, 0, image.width, image.height)
                    val result = SmartTradeApp.instance.tradingRepository.analyzeScreenBitmap(cropped)

                    handler.post {
                        updateStatusText(result.statusMessageHinglish)
                    }
                } else {
                    handler.post {
                        updateStatusText("Frame grab nahi ho saka. Screen active rakhein.")
                    }
                }
            } catch (e: Exception) {
                Log.e("FloatingAssistantService", "Frame capture error: ${e.message}")
            }
        }
    }

    private fun updateStatusText(text: String) {
        val statusLine = floatingView?.findViewWithTag<TextView>("status_line")
        statusLine?.text = text
    }

    private fun createBubbleBackground(): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = 40f
            setColor(Color.parseColor("#131A26"))
            setStroke(3, Color.parseColor("#00E5FF"))
        }
    }

    private fun createCardBackground(): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = 24f
            setColor(Color.parseColor("#131A26"))
            setStroke(2, Color.parseColor("#28364F"))
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        continuousScanJob?.cancel()
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        if (floatingView != null) {
            windowManager?.removeView(floatingView)
        }
    }

    companion object {
        const val ACTION_START_PROJECTION = "com.example.service.START_PROJECTION"
        const val ACTION_STOP_SERVICE = "com.example.service.STOP_SERVICE"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"

        fun startServiceWithProjection(context: Context, resultCode: Int, data: Intent) {
            val intent = Intent(context, FloatingAssistantService::class.java).apply {
                action = ACTION_START_PROJECTION
                putExtra(EXTRA_RESULT_CODE, resultCode)
                putExtra(EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, FloatingAssistantService::class.java).apply {
                action = ACTION_STOP_SERVICE
            }
            context.startService(intent)
        }
    }
}
